// ContextShift – ChatGPT content script
// Re-reads the chat whenever it changes (new messages, streaming replies,
// switching chats) and sends it to the extension. It never stops watching.

const SOURCE_AI = "ChatGPT";

let lastSignature = "";
let timer = null;

function extract() {
  const conversation = [];

  document.querySelectorAll("[data-message-author-role]").forEach((node) => {
    const content = node.innerText ? node.innerText.trim() : "";
    const role = node.getAttribute("data-message-author-role");

    if (!content || !role) return;

    conversation.push({ role: role, content: content });
  });

  return conversation;
}

function sendIfChanged() {
  const conversation = extract();

  if (conversation.length === 0) return;

  const signature = JSON.stringify(conversation);
  if (signature === lastSignature) return;
  lastSignature = signature;

  try {
    const result = chrome.runtime.sendMessage({
      type: "CONVERSATION",
      sourceAI: SOURCE_AI,
      conversation: conversation
    });
    if (result && result.catch) result.catch(() => {});
  } catch (error) {
    // The extension was reloaded while this tab was open. Refresh the page.
  }
}

const observer = new MutationObserver(() => {
  clearTimeout(timer);
  timer = setTimeout(sendIfChanged, 1000);
});

observer.observe(document.body, {
  childList: true,
  subtree: true,
  characterData: true
});

sendIfChanged();
